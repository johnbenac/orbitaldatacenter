SPACECRAFT MATERIAL AND TEXTURE BANK

Original procedural visual representations for PDR studies.
Open material-library.json for composition, finish, sources and limitations.
Open texture-manifest.json for illustrative physical repeat scales.
The active spacecraft assignments and parent mass accounting are exported separately from the Materials & finishes page and MEL.

Files: color in sRGB; normal and roughness as linear data.
Surface finish is not a thermal property, structural allowable, measured BRDF, vendor selection or material qualification.
Maps use assets/materials/ paths to match the source catalog. Primary documents are linked, not redistributed.
